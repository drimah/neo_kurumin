﻿# ============================================================
#  NEO KURUMIN LAB v0.1 - cria a máquina virtual no Windows
# ============================================================
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$VM     = 'Neo Kurumin'
$Base   = Join-Path $env:USERPROFILE 'NeoKurumin-Lab'
$Raiz   = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$Pacote = Join-Path $Raiz 'pacote\neo-kurumin-pacote.iso'
$VBM    = Join-Path $env:ProgramFiles 'Oracle\VirtualBox\VBoxManage.exe'

function Passo($t) { Write-Host ""; Write-Host $t -ForegroundColor Green }
function Ok($t)    { Write-Host "  [OK] $t" -ForegroundColor Green }
function Aviso($t) { Write-Host "  [!] $t" -ForegroundColor Yellow }
function VB  { $ErrorActionPreference = 'Continue'; & $VBM @args 2>&1 | Out-Host; return $LASTEXITCODE }
function VBq { $ErrorActionPreference = 'Continue'; & $VBM @args 2>&1 | Out-Null; return $LASTEXITCODE }

New-Item -ItemType Directory -Force -Path $Base | Out-Null

# ---------- 1. VirtualBox ----------
Passo '[1/4] VirtualBox'
if (-not (Test-Path $VBM)) {
  if (Get-Command winget -ErrorAction SilentlyContinue) {
    Write-Host '  Instalando a VirtualBox (o Windows pode pedir permissão)...'
    & winget install --id Microsoft.VCRedist.2015+.x64 -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
    & winget install --id Oracle.VirtualBox -e --accept-package-agreements --accept-source-agreements
  } else {
    Start-Process 'https://www.virtualbox.org/wiki/Downloads'
    throw 'Instale a VirtualBox pelo site que abriu e rode este instalador de novo.'
  }
}
if (-not (Test-Path $VBM)) { throw 'A VirtualBox não foi instalada. Instale pelo site virtualbox.org e rode de novo.' }
Ok ("VirtualBox " + (& $VBM --version))
try {
  if ((Get-CimInstance Win32_ComputerSystem).HypervisorPresent) {
    Aviso 'O Hyper-V/WSL está ligado no Windows: a máquina virtual pode ficar mais lenta (mas funciona).'
  }
} catch {}

# ---------- se a VM já existe ----------
if ((VBq showvminfo $VM) -eq 0) {
  Passo 'A máquina "Neo Kurumin" já existe.'
  $r = Read-Host '  Você já terminou de instalar o Kubuntu nela? (S/n)'
  if ($r -ne 'n' -and $r -ne 'N') {
    VBq storageattach $VM --storagectl SATA --port 1 --device 0 --type dvddrive --medium emptydrive | Out-Null
    Ok 'DVD do Kubuntu removido (agora ela liga direto no sistema instalado)'
  }
  VBq storageattach $VM --storagectl SATA --port 2 --device 0 --type dvddrive --medium $Pacote | Out-Null
  VB startvm $VM --type gui | Out-Null
  Ok 'Máquina ligada!'
  return
}

# ---------- 2. Baixar o Kubuntu 26.04 ----------
Passo '[2/4] Kubuntu 26.04 LTS (base do Neo Kurumin)'
$nome = $null; $url = $null
foreach ($u in @('https://cdimage.ubuntu.com/kubuntu/releases/26.04/release/',
                 'https://cdimage.ubuntu.com/kubuntu/releases/resolute/release/')) {
  try {
    $html = (Invoke-WebRequest $u -UseBasicParsing).Content
    $lista = [regex]::Matches($html, 'kubuntu-26\.04(\.\d+)?-desktop-amd64\.iso') | ForEach-Object { $_.Value } | Sort-Object -Unique
    if ($lista) {
      $nome = $lista | Sort-Object { [version]($_ -replace '^kubuntu-', '' -replace '-desktop-amd64\.iso$', '') } | Select-Object -Last 1
      $url = $u; break
    }
  } catch {}
}
if (-not $nome) { throw 'Não encontrei o Kubuntu 26.04 no site do Ubuntu. Verifique a internet e tente de novo.' }
$iso = Join-Path $Base $nome
$sums = (Invoke-WebRequest ($url + 'SHA256SUMS') -UseBasicParsing).Content
if ($sums -is [byte[]]) { $sums = [Text.Encoding]::ASCII.GetString($sums) }
$esperado = (($sums -split "`n") | Where-Object { $_ -match [regex]::Escape($nome) } | Select-Object -First 1) -replace '\s.*$', ''

$precisa = $true
if (Test-Path $iso) {
  Write-Host '  Conferindo o arquivo que já foi baixado...'
  if ((Get-FileHash $iso -Algorithm SHA256).Hash.ToLower() -eq $esperado.ToLower()) { $precisa = $false; Ok "$nome já baixado" }
}
if ($precisa) {
  Write-Host "  Baixando $nome (cerca de 5 GB). Se cair a internet, rode de novo que ele continua de onde parou."
  & curl.exe -L -C - --retry 5 -o $iso ($url + $nome)
  Write-Host '  Conferindo se o download veio perfeito...'
  if ((Get-FileHash $iso -Algorithm SHA256).Hash.ToLower() -ne $esperado.ToLower()) {
    Remove-Item $iso -Force
    throw 'O arquivo veio corrompido e foi apagado. Rode o instalador de novo.'
  }
  Ok 'Download conferido'
}

# ---------- 3. Criar a máquina ----------
Passo '[3/4] Criando a máquina virtual "Neo Kurumin"'
$ramGB = [math]::Round((Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB)
$mem = if ($ramGB -ge 16) { 8192 } elseif ($ramGB -ge 12) { 6144 } else { 4096 }
$cpu = [math]::Max(2, [math]::Min(8, [int]([Environment]::ProcessorCount / 2)))
if ((VB createvm --name $VM --ostype Ubuntu_64 --register --basefolder $Base) -ne 0) { throw 'Falha ao criar a máquina.' }
if ((VB modifyvm $VM --memory $mem --cpus $cpu --vram 128 --graphicscontroller vmsvga --firmware efi --ioapic on --nic1 nat --mouse usbtablet --boot1 disk --boot2 dvd --boot3 none --boot4 none) -ne 0) { throw 'Falha ao configurar a máquina.' }
if ((VBq modifyvm $VM --accelerate-3d on) -ne 0) { VBq modifyvm $VM --accelerate3d on | Out-Null }
if ((VBq modifyvm $VM --clipboard-mode bidirectional) -ne 0) { VBq modifyvm $VM --clipboard bidirectional | Out-Null }
if ((VBq modifyvm $VM --drag-and-drop bidirectional) -ne 0) { VBq modifyvm $VM --draganddrop bidirectional | Out-Null }
if ((VBq modifyvm $VM --audio-enabled on) -ne 0) { VBq modifyvm $VM --audio dsound | Out-Null }
$vdi = Join-Path $Base "$VM\NeoKurumin.vdi"
if ((VB createmedium disk --filename $vdi --size 61440 --format VDI) -ne 0) { throw 'Falha ao criar o disco.' }
VB storagectl $VM --name SATA --add sata --controller IntelAhci --portcount 4 --bootable on | Out-Null
VB storageattach $VM --storagectl SATA --port 0 --device 0 --type hdd --medium $vdi | Out-Null
VB storageattach $VM --storagectl SATA --port 1 --device 0 --type dvddrive --medium $iso | Out-Null
VB storageattach $VM --storagectl SATA --port 2 --device 0 --type dvddrive --medium $Pacote | Out-Null
Ok "Memória: $mem MB | Processadores: $cpu | Disco: 60 GB"

# ---------- 4. Ligar ----------
Passo '[4/4] Ligando a máquina'
VB startvm $VM --type gui | Out-Null
Ok 'Pronto! Siga o LEIA-ME para instalar o Kubuntu e virar Neo Kurumin.'
